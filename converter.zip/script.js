const API_KEY = "e8eab13facc49788d961a68e"; // Replace with your API key

const currencyTab = document.getElementById("currency-tab");
const currencyContainer = document.getElementById("currency-container");
const addCurrencyBtn = document.getElementById("add-currency-btn");
const currencyList = document.getElementById("currency-list");
const hideTab = document.getElementById("hide-tab");

const currencyToCountry = {
    AED: "ae", // United Arab Emirates
    AFN: "af", // Afghanistan
    ALL: "al", // Albania
    AMD: "am", // Armenia
    ANG: "cw", // Netherlands Antilles (Curaçao)
    AOA: "ao", // Angola
    ARS: "ar", // Argentina
    AUD: "au", // Australia
    AWG: "aw", // Aruba
    AZN: "az", // Azerbaijan
    BAM: "ba", // Bosnia and Herzegovina
    BBD: "bb", // Barbados
    BDT: "bd", // Bangladesh
    BGN: "bg", // Bulgaria
    BHD: "bh", // Bahrain
    BIF: "bi", // Burundi
    BMD: "bm", // Bermuda
    BND: "bn", // Brunei
    BOB: "bo", // Bolivia
    BRL: "br", // Brazil
    BSD: "bs", // Bahamas
    BTN: "bt", // Bhutan
    BWP: "bw", // Botswana
    BYN: "by", // Belarus
    BZD: "bz", // Belize
    CAD: "ca", // Canada
    CDF: "cd", // Democratic Republic of the Congo
    CHF: "ch", // Switzerland
    CLP: "cl", // Chile
    CNY: "cn", // China
    COP: "co", // Colombia
    CRC: "cr", // Costa Rica
    CUP: "cu", // Cuba
    CVE: "cv", // Cape Verde
    CZK: "cz", // Czech Republic
    DJF: "dj", // Djibouti
    DKK: "dk", // Denmark
    DOP: "do", // Dominican Republic
    DZD: "dz", // Algeria
    EGP: "eg", // Egypt
    ERN: "er", // Eritrea
    ETB: "et", // Ethiopia
    EUR: "eu", // European Union
    FJD: "fj", // Fiji
    FKP: "fk", // Falkland Islands
    FOK: "fo", // Faroe Islands
    GBP: "gb", // United Kingdom
    GEL: "ge", // Georgia
    GGP: "gg", // Guernsey
    GHS: "gh", // Ghana
    GIP: "gi", // Gibraltar
    GMD: "gm", // Gambia
    GNF: "gn", // Guinea
    GTQ: "gt", // Guatemala
    GYD: "gy", // Guyana
    HKD: "hk", // Hong Kong
    HNL: "hn", // Honduras
    HRK: "hr", // Croatia
    HTG: "ht", // Haiti
    HUF: "hu", // Hungary
    IDR: "id", // Indonesia
    ILS: "ps", // Palestine
    IMP: "im", // Isle of Man
    INR: "in", // India
    IQD: "iq", // Iraq
    IRR: "ir", // Iran
    ISK: "is", // Iceland
    JEP: "je", // Jersey
    JMD: "jm", // Jamaica
    JOD: "jo", // Jordan
    JPY: "jp", // Japan
    KES: "ke", // Kenya
    KGS: "kg", // Kyrgyzstan
    KHR: "kh", // Cambodia
    KID: "ki", // Kiribati
    KMF: "km", // Comoros
    KRW: "kr", // South Korea
    KWD: "kw", // Kuwait
    KYD: "ky", // Cayman Islands
    KZT: "kz", // Kazakhstan
    LAK: "la", // Laos
    LBP: "lb", // Lebanon
    LKR: "lk", // Sri Lanka
    LRD: "lr", // Liberia
    LSL: "ls", // Lesotho
    LYD: "ly", // Libya
    MAD: "ma", // Morocco
    MDL: "md", // Moldova
    MGA: "mg", // Madagascar
    MKD: "mk", // North Macedonia
    MMK: "mm", // Myanmar
    MNT: "mn", // Mongolia
    MOP: "mo", // Macau
    MRU: "mr", // Mauritania
    MUR: "mu", // Mauritius
    MVR: "mv", // Maldives
    MWK: "mw", // Malawi
    MXN: "mx", // Mexico
    MYR: "my", // Malaysia
    MZN: "mz", // Mozambique
    NAD: "na", // Namibia
    NGN: "ng", // Nigeria
    NIO: "ni", // Nicaragua
    NOK: "no", // Norway
    NPR: "np", // Nepal
    NZD: "nz", // New Zealand
    OMR: "om", // Oman
    PAB: "pa", // Panama
    PEN: "pe", // Peru
    PGK: "pg", // Papua New Guinea
    PHP: "ph", // Philippines
    PKR: "pk", // Pakistan
    PLN: "pl", // Poland
    PYG: "py", // Paraguay
    QAR: "qa", // Qatar
    RON: "ro", // Romania
    RSD: "rs", // Serbia
    RUB: "ru", // Russia
    RWF: "rw", // Rwanda
    SAR: "sa", // Saudi Arabia
    SBD: "sb", // Solomon Islands
    SCR: "sc", // Seychelles
    SDG: "sd", // Sudan
    SEK: "se", // Sweden
    SGD: "sg", // Singapore
    SHP: "sh", // Saint Helena
    SLE: "sl", // Sierra Leone
    SLL: "sl", // Sierra Leone
    SOS: "so", // Somalia
    SRD: "sr", // Suriname
    SSP: "ss", // South Sudan
    STN: "st", // São Tomé and Príncipe
    SYP: "sy", // Syria
    SZL: "sz", // Eswatini
    THB: "th", // Thailand
    TJS: "tj", // Tajikistan
    TMT: "tm", // Turkmenistan
    TND: "tn", // Tunisia
    TOP: "to", // Tonga
    TRY: "tr", // Turkey
    TTD: "tt", // Trinidad and Tobago
    TVD: "tv", // Tuvalu
    TWD: "tw", // Taiwan
    TZS: "tz", // Tanzania
    UAH: "ua", // Ukraine
    UGX: "ug", // Uganda
    USD: "us", // United States
    UYU: "uy", // Uruguay
    UZS: "uz", // Uzbekistan
    VES: "ve", // Venezuela
    VND: "vn", // Vietnam
    VUV: "vu", // Vanuatu
    WST: "ws", // Samoa
    XAF: "cm", // Central African CFA franc (Cameroon)
    XCD: "ag", // East Caribbean dollar (Antigua and Barbuda)
    XDR: "un", // Special Drawing Rights (United Nations)
    XOF: "bj", // West African CFA franc (Benin)
    XPF: "pf", // CFP franc (French Polynesia)
    YER: "ye", // Yemen
    ZAR: "za", // South Africa
    ZMW: "zm", // Zambia
    ZWL: "zw", // Zimbabwe
};

document.addEventListener("DOMContentLoaded", async () => {
    const lastUpdateElement = document.querySelector(".last-update");
    const CURRENCY_DATA_KEY = "currencyData";
    const LAST_UPDATED_KEY = "lastUpdated";

    let currencies = [];
    let exchangeRates = {};

    // Function to fetch exchange rates
    async function fetchExchangeRates(base = "USD") {
        try {
            const response = await fetch(`https://v6.exchangerate-api.com/v6/${API_KEY}/latest/${base}`);
            const data = await response.json();
            if (data.result === "error") throw new Error(data["error-type"]);
            return data.conversion_rates;
        } catch (error) {
            console.error("Error fetching exchange rates:", error);
            return null;
        }
    }

    // Function to save exchange rates and last updated date to localStorage
    function saveExchangeRates(rates) {
        if (rates) {
            localStorage.setItem(CURRENCY_DATA_KEY, JSON.stringify(rates));
            localStorage.setItem(LAST_UPDATED_KEY, new Date().toLocaleString());
            console.log("Exchange rates saved to localStorage.");
        }
    }

    // Function to load exchange rates and last updated date from localStorage
    function loadExchangeRates() {
        const savedRates = localStorage.getItem(CURRENCY_DATA_KEY);
        const lastUpdated = localStorage.getItem(LAST_UPDATED_KEY);

        if (savedRates && lastUpdated) {
            exchangeRates = JSON.parse(savedRates);
            console.log("Exchange rates loaded from localStorage.");
            return { rates: exchangeRates, lastUpdated };
        }
        return null;
    }

    // Function to update the .last-update element
    function updateLastUpdateElement(isOnline, lastUpdated = null) {
        if (isOnline) {
            lastUpdateElement.innerHTML = `<span class="green">🟢 Online </span> - Exchange rates are updated once per day.`;
        } else if (lastUpdated) {
            lastUpdateElement.innerHTML = `<span class="red">🔴 Offline </span> - Last Updated Date: <span class="date">${lastUpdated}</span>`;
        } else {
            lastUpdateElement.innerHTML = `<span class="red">🔴 Offline </span> - No saved exchange rates found.`;
        }
    }

    async function updateExchangeRates() {
        exchangeRates = await fetchExchangeRates("USD");
        updateCurrencyValues();
    }


    // Function to check if the app is online
    function isOnline() {
        return navigator.onLine;
    }

    // Initialize exchange rates
    async function initializeExchangeRates() {
        if (isOnline()) {
            // Fetch fresh exchange rates if online
            console.log("App is online. Fetching latest exchange rates...");
            exchangeRates = await fetchExchangeRates("USD");
            if (exchangeRates) {
                saveExchangeRates(exchangeRates);
                updateLastUpdateElement(true);
            }
        } else {
            // Load saved exchange rates if offline
            console.log("App is offline. Loading saved exchange rates...");
            const savedData = loadExchangeRates();
            if (savedData) {
                exchangeRates = savedData.rates;
                updateLastUpdateElement(false, savedData.lastUpdated);
            } else {
                console.error("No saved exchange rates found.");
                updateLastUpdateElement(false);
            }
        }
    }

    // Initialize the app
    await initializeExchangeRates();

    // Add event listeners for online/offline status
    window.addEventListener("online", async () => {
        console.log("App is online. Fetching latest exchange rates...");
        exchangeRates = await fetchExchangeRates("USD");
        if (exchangeRates) {
            saveExchangeRates(exchangeRates);
            updateLastUpdateElement(true);
        }
    });

    window.addEventListener("offline", () => {
        console.log("App is offline. Loading saved exchange rates...");
        const savedData = loadExchangeRates();
        if (savedData) {
            exchangeRates = savedData.rates;
            updateLastUpdateElement(false, savedData.lastUpdated);
        } else {
            console.error("No saved exchange rates found.");
            updateLastUpdateElement(false);
        }
    });


    function updateCurrencyValues(baseValue = 0, baseCurrency = "USD") {
        if (!exchangeRates) return;

        // Round the base value to 2 decimal places
        const roundedBaseValue = parseFloat(baseValue.toFixed(2));

        document.querySelectorAll(".currency-input input").forEach(input => {
            const currency = input.dataset.currency;
            if (currency !== baseCurrency) {
                // Calculate the converted value based on the base currency and exchange rates
                const convertedValue = roundedBaseValue * (exchangeRates[currency] / exchangeRates[baseCurrency]);

                // Round the converted value to 2 decimal places
                const roundedValue = convertedValue.toFixed(2);

                // Update the input field with the rounded value
                input.value = formatNumberWithCommas(roundedValue || 0);
            }
        });
    }

    function formatNumberWithCommas(value) {
        if (value === "" || value === ".") return value; // Allow empty input or just a decimal point

        value = String(value); // Ensure value is treated as a string
        let [integer, decimal] = value.split(".");

        integer = integer.replace(/\B(?=(\d{3})+(?!\d))/g, ","); // Add commas to integer part

        return decimal !== undefined ? `${integer}.${decimal}` : integer;
    }

    // Improved save function
    function saveCurrencyOrder() {
        const currencyOrder = Array.from(currencyContainer.children)
            .filter(item => item.classList.contains("currency-input"))
            .map(item => item.querySelector("input").dataset.currency);

        // Also update the currencies array to keep it in sync
        currencies = currencyOrder;

        localStorage.setItem("currencyOrder", JSON.stringify(currencyOrder));
        console.log("Saved currency order:", currencyOrder);
    }

    // Improved load function
    function loadCurrencyOrder() {
        try {
            const savedOrder = JSON.parse(localStorage.getItem("currencyOrder"));

            if (savedOrder && Array.isArray(savedOrder) && savedOrder.length > 0) {
                console.log("Loading saved currency order:", savedOrder);

                // Clear existing currencies
                currencyContainer.innerHTML = "";
                currencies = [];

                // Add each currency in the saved order
                savedOrder.forEach(currency => {
                    addCurrency(currency, false); // Don't save during loading (prevents recursion)
                });

                // Update the currencies array to match
                currencies = savedOrder;

                return true; // Successfully loaded
            }
        } catch (error) {
            console.error("Error loading currency order:", error);
        }

        return false; // Nothing loaded
    }

    function checkCurrencyCount() {
        const currencyInputs = document.querySelectorAll(".currency-input");
        const removeButtons = document.querySelectorAll(".remove-btn");

        if (currencyInputs.length > 2) {
            removeButtons.forEach(btn => btn.style.display = "flex");
        } else {
            removeButtons.forEach(btn => btn.style.display = "none");
        }
    }

    function updateAddButtonVisibility() {
        if (currencies.length === Object.keys(exchangeRates || {}).length) {
            addCurrencyBtn.style.display = "none"; // Hide the button
        } else {
            addCurrencyBtn.style.display = "flex"; // Show the button
        }
    }

    function closeCurrencyTab() {
        currencyTab.classList.remove("show");
        currencyTab.classList.add("hidden");
    }

    function openCurrencyTab() {
        currencyTab.classList.add("show");
        currencyTab.classList.remove("hidden");
    }

    // Modified addCurrency function
    function addCurrency(currency, shouldSave = true) {
        if (currencies.includes(currency)) return;

        currencies.push(currency);
        const currencyDiv = document.createElement("div");
        currencyDiv.classList.add("currency-input");
        currencyDiv.setAttribute("draggable", "true");

        // Get the country code for the currency
        const countryCode = currencyToCountry[currency] || "xx"; // "xx" is a fallback for unknown currencies

        currencyDiv.innerHTML = `
            <div class="flag"><span class="fi fi-${countryCode}"></span></div>
            <label>${currency}</label>
            <input type="text" data-currency="${currency}" value="0.00" data-previous-value="0">
            <button class="remove-btn"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"/></svg></button>
        `;

        currencyContainer.appendChild(currencyDiv);

        const inputField = currencyDiv.querySelector("input");

        checkCurrencyCount();
        updateAddButtonVisibility();

        // Only save if shouldSave is true (to prevent recursion during loading)
        if (shouldSave) {
            saveCurrencyOrder();
        }

        // Handle input formatting
        inputField.addEventListener("input", (event) => {
            let rawValue = event.target.value ? event.target.value.replace(/,/g, '') : "";

            if (!/^\d*\.?\d*$/.test(rawValue)) {
                event.target.value = event.target.dataset.previousValue || "0";
                return;
            }

            event.target.dataset.previousValue = rawValue;
            event.target.value = formatNumberWithCommas(rawValue);
            updateCurrencyValues(parseFloat(rawValue) || 0, event.target.dataset.currency);
        });

        // Select all text on focus
        inputField.addEventListener("focus", (event) => {
            event.target.select();
        });

        // Remove currency
        currencyDiv.querySelector(".remove-btn").addEventListener("click", () => {
            currencyDiv.remove();
            currencies = currencies.filter(c => c !== currency);
            checkCurrencyCount();
            updateAddButtonVisibility();
            saveCurrencyOrder();
        });

        // Update the newly added currency immediately
        let baseInput = document.querySelector(".currency-input input:not([value='0'])");

        if (!baseInput) {
            // If no input has a value yet, pick the first one
            baseInput = document.querySelector(".currency-input input");
        }

        if (baseInput) {
            // Use the actual displayed value of the input field
            let baseValue = parseFloat(baseInput.value.replace(/,/g, '') || 1); // Default to 1 if empty
            let baseCurrency = baseInput.dataset.currency;
            updateCurrencyValues(baseValue, baseCurrency);
        }
    }

    // Set up event listeners
    currencyTab.addEventListener("click", (event) => {
        if (!(event.target instanceof HTMLInputElement)) return;
        if (!event.target.value) return;

        let rawValue = event.target.value.replace(/,/g, '');

        if (!/^\d*\.?\d*$/.test(rawValue)) {
            event.target.value = event.target.dataset.previousValue || "0";
            return;
        }

        event.target.dataset.previousValue = rawValue;
        event.target.value = formatNumberWithCommas(rawValue);
        updateCurrencyValues(parseFloat(rawValue) || 0, event.target.dataset.currency);
    });

    currencyContainer.addEventListener("focus", (event) => {
        if (event.target.tagName === "INPUT") {
            event.target.select(); // Select content on focus
        }
    });

    addCurrencyBtn.addEventListener("click", async () => {
        currencyList.innerHTML = "";

        if (!exchangeRates) {
            exchangeRates = await fetchExchangeRates("USD");
        }

        // Sort currencies alphabetically
        const sortedCurrencies = Object.keys(exchangeRates).sort((a, b) => a.localeCompare(b));

        sortedCurrencies.forEach(currency => {
            if (!currencies.includes(currency)) {
                const option = document.createElement("div");
                option.classList.add("currency-option");

                // Get the country code for the currency
                const countryCode = currencyToCountry[currency] || "xx"; // "xx" is a fallback for unknown currencies

                // Add the flag and currency code to the option
                option.innerHTML = `
                    <span class="fi fi-${countryCode}"></span>
                    <span>${currency}</span>
                `;

                option.addEventListener("click", () => {
                    addCurrency(currency);
                    closeCurrencyTab();
                });

                currencyList.appendChild(option);
            }
        });

        openCurrencyTab();
    });

    hideTab.addEventListener("click", () => {
        closeCurrencyTab();
    });

    // Drag and drop functionality
    let draggedItem = null;

    // Drag start event
    currencyContainer.addEventListener("dragstart", (event) => {
        if (event.target.classList.contains("currency-input")) {
            draggedItem = event.target;
            event.target.style.opacity = "1"; // Visual feedback
            // event.target.style.background = "dfdfdf8a"; // Visual feedback
            event.target.style.background = "rgba(253, 253, 253, 0.25)"; // Visual feedback
            event.target.style.opacity = "0.5"; // Visual feedback
        }
    });

    // Drag over event
    currencyContainer.addEventListener("dragover", (event) => {
        event.preventDefault(); // Allow dropping

        // Find the nearest .currency-input element
        const targetItem = event.target.closest(".currency-input");

        if (targetItem) {
            // targetItem.style.border = "2px solid orange"; // Visual feedback
            targetItem.style.background = "rgba(255, 199, 46, 0.8)"; // Visual feedback
        }
    });

    // Drag leave event
    currencyContainer.addEventListener("dragleave", (event) => {
        // Check if the cursor is leaving the .currency-input container
        if (
            event.target.classList.contains("currency-input") &&
            !event.target.contains(event.relatedTarget) // Ensure the cursor is leaving the container, not just moving to a child
        ) {
            event.target.style.background = "white"; // Reset background
            event.target.style.border = "none"; // Reset border
            event.target.style.borderBottom = "1px solid #dfdfdf8a"; // Reset bottom border
            event.target.style.opacity = "1"; // Visual feedback
        }
    });

    // Drop event
    currencyContainer.addEventListener("drop", (event) => {
        event.preventDefault();

        // Find the nearest .currency-input element
        const targetItem = event.target.closest(".currency-input");

        if (targetItem && draggedItem !== targetItem) {
            // Remove visual feedback
            targetItem.style.border = "none"; // Reset border
            targetItem.style.background = "white"; // Reset background
            targetItem.style.borderBottom = "1px solid #dfdfdf8a"; // Reset bottom border
            event.target.style.opacity = "1"; // Reset opacity


            // Reorder the elements
            const container = currencyContainer;
            const items = Array.from(container.children);

            const draggedIndex = items.indexOf(draggedItem);
            const targetIndex = items.indexOf(targetItem);

            if (draggedIndex < targetIndex) {
                container.insertBefore(draggedItem, targetItem.nextSibling);
            } else {
                container.insertBefore(draggedItem, targetItem);
            }

            saveCurrencyOrder(); // Save the updated order
        }

        // Reset styles for the dragged item
        if (draggedItem) {
            draggedItem.style.opacity = "1"; // Reset opacity
            draggedItem.style.background = "white"; // Reset background
        }
    });

    // Drag end event
    currencyContainer.addEventListener("dragend", (event) => {
        if (event.target.classList.contains("currency-input")) {
            // Reset styles for the dragged item
            event.target.style.opacity = "1"; // Reset opacity
            event.target.style.background = "white"; // Reset background

            // Reset styles for all currency inputs
            document.querySelectorAll(".currency-input").forEach(item => {
                item.style.border = "none"; // Reset border
                item.style.background = "white"; // Reset background
                item.style.borderBottom = "1px solid #dfdfdf8a"; // Reset bottom border
            });
        }
    });

    // Keyboard navigation for currency selection
    let currentLetter = "";
    let currentIndex = 0;
    let matchingCurrencies = [];
    let highlightedCurrency = null;

    document.addEventListener("keydown", (event) => {
        if (!currencyTab.classList.contains("hidden")) {
            if (!currencyList) return;

            const pressedKey = event.key.toUpperCase();
            const currencyItems = Array.from(currencyList.children);

            if (/^[A-Z]$/.test(pressedKey)) {
                if (currentLetter !== pressedKey) {
                    currentLetter = pressedKey;
                    currentIndex = 0;
                    matchingCurrencies = currencyItems.filter(option =>
                        option.textContent.trim().toUpperCase().startsWith(pressedKey)
                    );
                }

                if (matchingCurrencies.length > 0) {
                    removeHoverHighlight();
                    updateHighlight(matchingCurrencies[currentIndex]);
                    currentIndex = (currentIndex + 1) % matchingCurrencies.length;
                }
            } else if (event.key === "ArrowDown") {
                event.preventDefault();
                currentIndex = 0;
                removeHoverHighlight();
                if (!highlightedCurrency) {
                    updateHighlight(currencyItems[0]);
                } else {
                    let nextItem = highlightedCurrency.nextElementSibling;
                    if (nextItem) updateHighlight(nextItem);
                }
            } else if (event.key === "ArrowUp") {
                event.preventDefault();
                currentIndex = 0;
                removeHoverHighlight();
                if (!highlightedCurrency) {
                    updateHighlight(currencyItems[currencyItems.length - 1]);
                } else {
                    let prevItem = highlightedCurrency.previousElementSibling;
                    if (prevItem) updateHighlight(prevItem);
                }
            } else if (event.key === "Enter") {
                event.preventDefault();
                if (highlightedCurrency) {
                    addCurrency(highlightedCurrency.textContent.trim());
                    closeCurrencyTab();
                    updateAddButtonVisibility();
                }
            } else if (event.key === "Escape") {
                event.preventDefault();
                closeCurrencyTab();
            }
        }
    });

    function updateHighlight(newItem) {
        removeHighlight();
        highlightedCurrency = newItem;
        highlightedCurrency.classList.add("currency-active");
        highlightedCurrency.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }

    function removeHighlight() {
        const previousHighlight = document.querySelector(".currency-active");
        if (previousHighlight) {
            previousHighlight.classList.remove("currency-active");
        }
    }

    function removeHoverHighlight() {
        const hoverHighlight = document.querySelector(".currency-option:hover");
        if (hoverHighlight) {
            hoverHighlight.classList.remove("currency-active");
        }
    }

    currencyList.addEventListener("mouseover", (event) => {
        if (event.target.classList.contains("currency-option")) {
            removeHighlight();
            event.target.classList.add("currency-active");
            highlightedCurrency = event.target;
        }
    });

    // Numbers to words
    const numToTextElement = document.getElementById("num-to-text");
    if (numToTextElement) {
        currencyContainer.addEventListener("input", (event) => {
            if (event.target.tagName === "INPUT") {
                const inputField = event.target;
                const rawValue = inputField.value.replace(/,/g, ''); // Remove commas
                const number = parseFloat(rawValue);

                if (!isNaN(number) && typeof numberToWords !== 'undefined') {
                    let words = numberToWords.toWords(number); // Use the library
                    words = words.charAt(0).toUpperCase() + words.slice(1); // Capitalize the first letter
                    numToTextElement.textContent = words.replace(/,/g, ''); // Update the element
                } else {
                    numToTextElement.textContent = "ABC..."; // Clear if input is invalid
                }
            }
        });
    }

    // Initialize application
    await updateExchangeRates(); // Load exchange rates first

    // Try to load saved currencies
    const loadedSuccessfully = loadCurrencyOrder();

    // Only load defaults if nothing was loaded from localStorage
    if (!loadedSuccessfully) {
        console.log("No saved currencies found, loading defaults");
        addCurrency("USD");
        addCurrency("EUR");
    }

    checkCurrencyCount();
    updateAddButtonVisibility();

    // Remove any existing colored displays
    document.querySelectorAll(".colored-display").forEach(display => {
        display.remove();
    });

    // Reset input styles
    document.querySelectorAll(".currency-input input").forEach(input => {
        input.style.color = ""; // Reset to default color
        input.style.caretColor = ""; // Reset to default caret color
    });

    // Convert any input-wrapper divs back to normal inputs
    document.querySelectorAll(".input-wrapper").forEach(wrapper => {
        const input = wrapper.querySelector("input");
        if (input) {
            wrapper.parentNode.insertBefore(input, wrapper);
            wrapper.remove();
        }
    });
});

// document.addEventListener("DOMContentLoaded", async () => {
//     const lastUpdateElement = document.querySelector(".last-update");
//     const CURRENCY_DATA_KEY = "currencyData";
//     const LAST_UPDATED_KEY = "lastUpdated";

//     let currencies = [];
//     let exchangeRates = {};

//     // Function to fetch exchange rates
//     async function fetchExchangeRates(base = "USD") {
//         try {
//             const response = await fetch(`https://v6.exchangerate-api.com/v6/${API_KEY}/latest/${base}`);
//             const data = await response.json();
//             if (data.result === "error") throw new Error(data["error-type"]);
//             return data.conversion_rates;
//         } catch (error) {
//             console.error("Error fetching exchange rates:", error);
//             return null;
//         }
//     }

//     // Function to save exchange rates and last updated date to localStorage
//     function saveExchangeRates(rates) {
//         if (rates) {
//             localStorage.setItem(CURRENCY_DATA_KEY, JSON.stringify(rates));
//             localStorage.setItem(LAST_UPDATED_KEY, new Date().toLocaleString());
//             console.log("Exchange rates saved to localStorage.");
//         }
//     }

//     // Function to load exchange rates and last updated date from localStorage
//     function loadExchangeRates() {
//         const savedRates = localStorage.getItem(CURRENCY_DATA_KEY);
//         const lastUpdated = localStorage.getItem(LAST_UPDATED_KEY);

//         if (savedRates && lastUpdated) {
//             exchangeRates = JSON.parse(savedRates);
//             console.log("Exchange rates loaded from localStorage.");
//             return { rates: exchangeRates, lastUpdated };
//         }
//         return null;
//     }

//     // Function to update the .last-update element
//     function updateLastUpdateElement(isOnline, lastUpdated) {
//         if (isOnline) {
//             lastUpdateElement.textContent = "🟢 Online - Exchange rates are automatically updated once per day.";
//         } else {
//             lastUpdateElement.textContent = `🔴 Offline - Exchange rates may be outdated. Last Updated Date: ${lastUpdated}`;
//         }
//     }

//     // Function to check if the app is online
//     function isOnline() {
//         return navigator.onLine;
//     }

//     // Initialize exchange rates
//     async function initializeExchangeRates() {
//         if (isOnline()) {
//             // Fetch fresh exchange rates if online
//             exchangeRates = await fetchExchangeRates("USD");
//             if (exchangeRates) {
//                 saveExchangeRates(exchangeRates);
//                 updateLastUpdateElement(true);
//             }
//         } else {
//             // Load saved exchange rates if offline
//             const savedData = loadExchangeRates();
//             if (savedData) {
//                 exchangeRates = savedData.rates;
//                 updateLastUpdateElement(false, savedData.lastUpdated);
//             } else {
//                 console.error("No saved exchange rates found.");
//                 updateLastUpdateElement(false, "Never");
//             }
//         }
//     }

//     async function updateExchangeRates() {
//         exchangeRates = await fetchExchangeRates("USD");
//         updateCurrencyValues();
//     }

//     // Initialize the app
//     await initializeExchangeRates();

//     // Add event listeners for online/offline status
//     window.addEventListener("online", async () => {
//         console.log("App is online. Fetching latest exchange rates...");
//         exchangeRates = await fetchExchangeRates("USD");
//         if (exchangeRates) {
//             saveExchangeRates(exchangeRates);
//             updateLastUpdateElement(true);
//         }
//     });

//     window.addEventListener("offline", () => {
//         console.log("App is offline. Loading saved exchange rates...");
//         const savedData = loadExchangeRates();
//         if (savedData) {
//             exchangeRates = savedData.rates;
//             updateLastUpdateElement(false, savedData.lastUpdated);
//         } else {
//             console.error("No saved exchange rates found.");
//             updateLastUpdateElement(false, "Never");
//         }
//     });


//     function updateCurrencyValues(baseValue = 0, baseCurrency = "USD") {
//         if (!exchangeRates) return;

//         // Round the base value to 2 decimal places
//         const roundedBaseValue = parseFloat(baseValue.toFixed(2));

//         document.querySelectorAll(".currency-input input").forEach(input => {
//             const currency = input.dataset.currency;
//             if (currency !== baseCurrency) {
//                 // Calculate the converted value based on the base currency and exchange rates
//                 const convertedValue = roundedBaseValue * (exchangeRates[currency] / exchangeRates[baseCurrency]);

//                 // Round the converted value to 2 decimal places
//                 const roundedValue = convertedValue.toFixed(2);

//                 // Update the input field with the rounded value
//                 input.value = formatNumberWithCommas(roundedValue || 0);
//             }
//         });
//     }

//     function formatNumberWithCommas(value) {
//         if (value === "" || value === ".") return value; // Allow empty input or just a decimal point

//         value = String(value); // Ensure value is treated as a string
//         let [integer, decimal] = value.split(".");

//         integer = integer.replace(/\B(?=(\d{3})+(?!\d))/g, ","); // Add commas to integer part

//         return decimal !== undefined ? `${integer}.${decimal}` : integer;
//     }

//     // Improved save function
//     function saveCurrencyOrder() {
//         const currencyOrder = Array.from(currencyContainer.children)
//             .filter(item => item.classList.contains("currency-input"))
//             .map(item => item.querySelector("input").dataset.currency);

//         // Also update the currencies array to keep it in sync
//         currencies = currencyOrder;

//         localStorage.setItem("currencyOrder", JSON.stringify(currencyOrder));
//         console.log("Saved currency order:", currencyOrder);
//     }

//     // Improved load function
//     function loadCurrencyOrder() {
//         try {
//             const savedOrder = JSON.parse(localStorage.getItem("currencyOrder"));

//             if (savedOrder && Array.isArray(savedOrder) && savedOrder.length > 0) {
//                 console.log("Loading saved currency order:", savedOrder);

//                 // Clear existing currencies
//                 currencyContainer.innerHTML = "";
//                 currencies = [];

//                 // Add each currency in the saved order
//                 savedOrder.forEach(currency => {
//                     addCurrency(currency, false); // Don't save during loading (prevents recursion)
//                 });

//                 // Update the currencies array to match
//                 currencies = savedOrder;

//                 return true; // Successfully loaded
//             }
//         } catch (error) {
//             console.error("Error loading currency order:", error);
//         }

//         return false; // Nothing loaded
//     }

//     function checkCurrencyCount() {
//         const currencyInputs = document.querySelectorAll(".currency-input");
//         const removeButtons = document.querySelectorAll(".remove-btn");

//         if (currencyInputs.length > 2) {
//             removeButtons.forEach(btn => btn.style.display = "flex");
//         } else {
//             removeButtons.forEach(btn => btn.style.display = "none");
//         }
//     }

//     function updateAddButtonVisibility() {
//         if (currencies.length === Object.keys(exchangeRates || {}).length) {
//             addCurrencyBtn.style.display = "none"; // Hide the button
//         } else {
//             addCurrencyBtn.style.display = "flex"; // Show the button
//         }
//     }

//     function closeCurrencyTab() {
//         currencyTab.classList.remove("show");
//         currencyTab.classList.add("hidden");
//     }

//     function openCurrencyTab() {
//         currencyTab.classList.add("show");
//         currencyTab.classList.remove("hidden");
//     }

//     // Modified addCurrency function
//     function addCurrency(currency, shouldSave = true) {
//         if (currencies.includes(currency)) return;

//         currencies.push(currency);
//         const currencyDiv = document.createElement("div");
//         currencyDiv.classList.add("currency-input");
//         currencyDiv.setAttribute("draggable", "true");

//         // Get the country code for the currency
//         const countryCode = currencyToCountry[currency] || "xx"; // "xx" is a fallback for unknown currencies

//         currencyDiv.innerHTML = `
//             <div class="flag"><span class="fi fi-${countryCode}"></span></div>
//             <label>${currency}</label>
//             <input type="text" data-currency="${currency}" value="0.00" data-previous-value="0">
//             <button class="remove-btn"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"/></svg></button>
//         `;

//         currencyContainer.appendChild(currencyDiv);

//         const inputField = currencyDiv.querySelector("input");

//         checkCurrencyCount();
//         updateAddButtonVisibility();

//         // Only save if shouldSave is true (to prevent recursion during loading)
//         if (shouldSave) {
//             saveCurrencyOrder();
//         }

//         // Handle input formatting
//         inputField.addEventListener("input", (event) => {
//             let rawValue = event.target.value ? event.target.value.replace(/,/g, '') : "";

//             if (!/^\d*\.?\d*$/.test(rawValue)) {
//                 event.target.value = event.target.dataset.previousValue || "0";
//                 return;
//             }

//             event.target.dataset.previousValue = rawValue;
//             event.target.value = formatNumberWithCommas(rawValue);
//             updateCurrencyValues(parseFloat(rawValue) || 0, event.target.dataset.currency);
//         });

//         // Select all text on focus
//         inputField.addEventListener("focus", (event) => {
//             event.target.select();
//         });

//         // Remove currency
//         currencyDiv.querySelector(".remove-btn").addEventListener("click", () => {
//             currencyDiv.remove();
//             currencies = currencies.filter(c => c !== currency);
//             checkCurrencyCount();
//             updateAddButtonVisibility();
//             saveCurrencyOrder();
//         });

//         // Update the newly added currency immediately
//         let baseInput = document.querySelector(".currency-input input:not([value='0'])");

//         if (!baseInput) {
//             // If no input has a value yet, pick the first one
//             baseInput = document.querySelector(".currency-input input");
//         }

//         if (baseInput) {
//             // Use the actual displayed value of the input field
//             let baseValue = parseFloat(baseInput.value.replace(/,/g, '') || 1); // Default to 1 if empty
//             let baseCurrency = baseInput.dataset.currency;
//             updateCurrencyValues(baseValue, baseCurrency);
//         }
//     }

//     // Set up event listeners
//     currencyTab.addEventListener("click", (event) => {
//         if (!(event.target instanceof HTMLInputElement)) return;
//         if (!event.target.value) return;

//         let rawValue = event.target.value.replace(/,/g, '');

//         if (!/^\d*\.?\d*$/.test(rawValue)) {
//             event.target.value = event.target.dataset.previousValue || "0";
//             return;
//         }

//         event.target.dataset.previousValue = rawValue;
//         event.target.value = formatNumberWithCommas(rawValue);
//         updateCurrencyValues(parseFloat(rawValue) || 0, event.target.dataset.currency);
//     });

//     currencyContainer.addEventListener("focus", (event) => {
//         if (event.target.tagName === "INPUT") {
//             event.target.select(); // Select content on focus
//         }
//     });

//     addCurrencyBtn.addEventListener("click", async () => {
//         currencyList.innerHTML = "";

//         if (!exchangeRates) {
//             exchangeRates = await fetchExchangeRates("USD");
//         }

//         // Sort currencies alphabetically
//         const sortedCurrencies = Object.keys(exchangeRates).sort((a, b) => a.localeCompare(b));

//         sortedCurrencies.forEach(currency => {
//             if (!currencies.includes(currency)) {
//                 const option = document.createElement("div");
//                 option.classList.add("currency-option");

//                 // Get the country code for the currency
//                 const countryCode = currencyToCountry[currency] || "xx"; // "xx" is a fallback for unknown currencies

//                 // Add the flag and currency code to the option
//                 option.innerHTML = `
//                     <span class="fi fi-${countryCode}"></span>
//                     <span>${currency}</span>
//                 `;

//                 option.addEventListener("click", () => {
//                     addCurrency(currency);
//                     closeCurrencyTab();
//                 });

//                 currencyList.appendChild(option);
//             }
//         });

//         openCurrencyTab();
//     });

//     hideTab.addEventListener("click", () => {
//         closeCurrencyTab();
//     });

//     // Drag and drop functionality
//     let draggedItem = null;

//     // Drag start event
//     currencyContainer.addEventListener("dragstart", (event) => {
//         if (event.target.classList.contains("currency-input")) {
//             draggedItem = event.target;
//             event.target.style.opacity = "1"; // Visual feedback
//             // event.target.style.background = "dfdfdf8a"; // Visual feedback
//             event.target.style.background = "rgba(253, 253, 253, 0.25)"; // Visual feedback
//             event.target.style.opacity = "0.5"; // Visual feedback
//         }
//     });

//     // Drag over event
//     currencyContainer.addEventListener("dragover", (event) => {
//         event.preventDefault(); // Allow dropping

//         // Find the nearest .currency-input element
//         const targetItem = event.target.closest(".currency-input");

//         if (targetItem) {
//             // targetItem.style.border = "2px solid orange"; // Visual feedback
//             targetItem.style.background = "rgba(255, 199, 46, 0.8)"; // Visual feedback
//         }
//     });

//     // Drag leave event
//     currencyContainer.addEventListener("dragleave", (event) => {
//         // Check if the cursor is leaving the .currency-input container
//         if (
//             event.target.classList.contains("currency-input") &&
//             !event.target.contains(event.relatedTarget) // Ensure the cursor is leaving the container, not just moving to a child
//         ) {
//             event.target.style.background = "white"; // Reset background
//             event.target.style.border = "none"; // Reset border
//             event.target.style.borderBottom = "1px solid #dfdfdf8a"; // Reset bottom border
//             event.target.style.opacity = "1"; // Visual feedback
//         }
//     });

//     // Drop event
//     currencyContainer.addEventListener("drop", (event) => {
//         event.preventDefault();

//         // Find the nearest .currency-input element
//         const targetItem = event.target.closest(".currency-input");

//         if (targetItem && draggedItem !== targetItem) {
//             // Remove visual feedback
//             targetItem.style.border = "none"; // Reset border
//             targetItem.style.background = "white"; // Reset background
//             targetItem.style.borderBottom = "1px solid #dfdfdf8a"; // Reset bottom border
//             event.target.style.opacity = "1"; // Reset opacity


//             // Reorder the elements
//             const container = currencyContainer;
//             const items = Array.from(container.children);

//             const draggedIndex = items.indexOf(draggedItem);
//             const targetIndex = items.indexOf(targetItem);

//             if (draggedIndex < targetIndex) {
//                 container.insertBefore(draggedItem, targetItem.nextSibling);
//             } else {
//                 container.insertBefore(draggedItem, targetItem);
//             }

//             saveCurrencyOrder(); // Save the updated order
//         }

//         // Reset styles for the dragged item
//         if (draggedItem) {
//             draggedItem.style.opacity = "1"; // Reset opacity
//             draggedItem.style.background = "white"; // Reset background
//         }
//     });

//     // Drag end event
//     currencyContainer.addEventListener("dragend", (event) => {
//         if (event.target.classList.contains("currency-input")) {
//             // Reset styles for the dragged item
//             event.target.style.opacity = "1"; // Reset opacity
//             event.target.style.background = "white"; // Reset background

//             // Reset styles for all currency inputs
//             document.querySelectorAll(".currency-input").forEach(item => {
//                 item.style.border = "none"; // Reset border
//                 item.style.background = "white"; // Reset background
//                 item.style.borderBottom = "1px solid #dfdfdf8a"; // Reset bottom border
//             });
//         }
//     });

//     // Keyboard navigation for currency selection
//     let currentLetter = "";
//     let currentIndex = 0;
//     let matchingCurrencies = [];
//     let highlightedCurrency = null;

//     document.addEventListener("keydown", (event) => {
//         if (!currencyTab.classList.contains("hidden")) {
//             if (!currencyList) return;

//             const pressedKey = event.key.toUpperCase();
//             const currencyItems = Array.from(currencyList.children);

//             if (/^[A-Z]$/.test(pressedKey)) {
//                 if (currentLetter !== pressedKey) {
//                     currentLetter = pressedKey;
//                     currentIndex = 0;
//                     matchingCurrencies = currencyItems.filter(option =>
//                         option.textContent.trim().toUpperCase().startsWith(pressedKey)
//                     );
//                 }

//                 if (matchingCurrencies.length > 0) {
//                     removeHoverHighlight();
//                     updateHighlight(matchingCurrencies[currentIndex]);
//                     currentIndex = (currentIndex + 1) % matchingCurrencies.length;
//                 }
//             } else if (event.key === "ArrowDown") {
//                 event.preventDefault();
//                 currentIndex = 0;
//                 removeHoverHighlight();
//                 if (!highlightedCurrency) {
//                     updateHighlight(currencyItems[0]);
//                 } else {
//                     let nextItem = highlightedCurrency.nextElementSibling;
//                     if (nextItem) updateHighlight(nextItem);
//                 }
//             } else if (event.key === "ArrowUp") {
//                 event.preventDefault();
//                 currentIndex = 0;
//                 removeHoverHighlight();
//                 if (!highlightedCurrency) {
//                     updateHighlight(currencyItems[currencyItems.length - 1]);
//                 } else {
//                     let prevItem = highlightedCurrency.previousElementSibling;
//                     if (prevItem) updateHighlight(prevItem);
//                 }
//             } else if (event.key === "Enter") {
//                 event.preventDefault();
//                 if (highlightedCurrency) {
//                     addCurrency(highlightedCurrency.textContent.trim());
//                     closeCurrencyTab();
//                     updateAddButtonVisibility();
//                 }
//             } else if (event.key === "Escape") {
//                 event.preventDefault();
//                 closeCurrencyTab();
//             }
//         }
//     });

//     function updateHighlight(newItem) {
//         removeHighlight();
//         highlightedCurrency = newItem;
//         highlightedCurrency.classList.add("currency-active");
//         highlightedCurrency.scrollIntoView({ behavior: "smooth", block: "nearest" });
//     }

//     function removeHighlight() {
//         const previousHighlight = document.querySelector(".currency-active");
//         if (previousHighlight) {
//             previousHighlight.classList.remove("currency-active");
//         }
//     }

//     function removeHoverHighlight() {
//         const hoverHighlight = document.querySelector(".currency-option:hover");
//         if (hoverHighlight) {
//             hoverHighlight.classList.remove("currency-active");
//         }
//     }

//     currencyList.addEventListener("mouseover", (event) => {
//         if (event.target.classList.contains("currency-option")) {
//             removeHighlight();
//             event.target.classList.add("currency-active");
//             highlightedCurrency = event.target;
//         }
//     });

//     // Numbers to words
//     const numToTextElement = document.getElementById("num-to-text");
//     if (numToTextElement) {
//         currencyContainer.addEventListener("input", (event) => {
//             if (event.target.tagName === "INPUT") {
//                 const inputField = event.target;
//                 const rawValue = inputField.value.replace(/,/g, ''); // Remove commas
//                 const number = parseFloat(rawValue);

//                 if (!isNaN(number) && typeof numberToWords !== 'undefined') {
//                     let words = numberToWords.toWords(number); // Use the library
//                     words = words.charAt(0).toUpperCase() + words.slice(1); // Capitalize the first letter
//                     numToTextElement.textContent = words.replace(/,/g, ''); // Update the element
//                 } else {
//                     numToTextElement.textContent = "ABC..."; // Clear if input is invalid
//                 }
//             }
//         });
//     }

//     // Initialize application
//     await updateExchangeRates(); // Load exchange rates first

//     // Try to load saved currencies
//     const loadedSuccessfully = loadCurrencyOrder();

//     // Only load defaults if nothing was loaded from localStorage
//     if (!loadedSuccessfully) {
//         console.log("No saved currencies found, loading defaults");
//         addCurrency("USD");
//         addCurrency("EUR");
//     }

//     checkCurrencyCount();
//     updateAddButtonVisibility();

//     // Remove any existing colored displays
//     document.querySelectorAll(".colored-display").forEach(display => {
//         display.remove();
//     });

//     // Reset input styles
//     document.querySelectorAll(".currency-input input").forEach(input => {
//         input.style.color = ""; // Reset to default color
//         input.style.caretColor = ""; // Reset to default caret color
//     });

//     // Convert any input-wrapper divs back to normal inputs
//     document.querySelectorAll(".input-wrapper").forEach(wrapper => {
//         const input = wrapper.querySelector("input");
//         if (input) {
//             wrapper.parentNode.insertBefore(input, wrapper);
//             wrapper.remove();
//         }
//     });
// });
